document.addEventListener("DOMContentLoaded", function () {
  const tarefaInput = document.getElementById("tarefaInput");
  const adicionarBotao = document.getElementById("adicionarBotao");
  const listaTarefas = document.getElementById("listaTarefas");

  function adicionarTarefa() {
    const texto = tarefaInput.value.trim();

    if (texto === "") {
      alert("Por favor, digite uma tarefa!");
      return;
    }

    const novaTarefa = document.createElement("li");

    const span = document.createElement("span");
    span.textContent = texto;

    span.addEventListener("click", function () {
      this.classList.toggle("concluida");
    });

    const botaoRemover = document.createElement("button");
    botaoRemover.textContent = "Remover";

    botaoRemover.addEventListener("click", function () {
      listaTarefas.removeChild(novaTarefa);
    });

    novaTarefa.appendChild(spanTexto);
    novaTarefa.appendChild(botaoRemover);

    listaTarefas.appendChild(novaTarefa);

    tarefaInput.value = "";
    tarefaInput.focus();
  }

  adicionarBotao.addEventListener("click", adicionarTarefa);

  tarefaInput.addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      adicionarTarefa();
    }
  });
});
