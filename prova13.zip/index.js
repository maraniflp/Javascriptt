function cadastrar() {
  document.getElementById("msg").textContent = "";
  const spans = document.querySelectorAll("span");
  spans.forEach((span) => (span.textContent = ""));

  try {
    const nome = document.getElementById("nome").value;
    const usuario = document.getElementById("usuario").value;
    const senha = document.getElementById("senha").value;
    const email = document.getElementById("email").value;
    const idade = document.getElementById("idade").value;

    if (!nome) throw new Error("Nome é obrigatório");
    if (!usuario) throw new Error("Usuário é obrigatório");
    if (!senha) throw new Error("Senha é obrigatória");
    if (!email) throw new Error("Email é obrigatório");
    if (!idade) throw new Error("Idade é obrigatória");

    if (!email.includes("@")) throw new Error("Email inválido");
    if (idade < 18) throw new Error("Idade mínima é 18 anos");
    if (senha.length < 6) throw new Error("Senha deve ter 6+ caracteres");

    document.getElementById("msg").textContent =
      "Cadastro realizado com sucesso!";
  } catch (erro) {
    const erros = {
      "Nome é obrigatório": "erroNome",
      "Usuário é obrigatório": "erroUsuario",
      "Senha é obrigatória": "erroSenha",
      "Email é obrigatório": "erroEmail",
      "Idade é obrigatória": "erroIdade",
      "Email inválido": "erroEmail",
      "Idade mínima é 18 anos": "erroIdade",
      "Senha deve ter 6+ caracteres": "erroSenha",
    };

    const campo = erros[erro.message];
    if (campo) {
      document.getElementById(campo).textContent = erro.message;
    }
  }
}
