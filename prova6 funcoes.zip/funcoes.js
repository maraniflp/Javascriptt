let tarefas = [];

const adicionarTarefa = function () {
  const input = document.getElementById("novaTarefa");
  const texto = input.value.trim();

  if (texto !== "") {
    tarefas.push({
      id: Date.now(),
      texto: texto,
      concluida: false,
    });

    input.value = "";

    mostrarTarefas();
  }
};

const mostrarTarefas = () => {
  const lista = document.getElementById("listaTarefas");
  lista.innerHTML = "";

  if (tarefas.length === 0) {
    lista.innerHTML = "<li>Nenhuma tarefa cadastrada</li>";
    return;
  }

  tarefas.forEach((tarefa, indice) => {
    const li = document.createElement("li");

    if (tarefa.concluida) {
      li.style.textDecoration = "line-through";
      li.style.color = "gray";
    }

    li.innerHTML = `
            <span>${indice + 1}. ${tarefa.texto}</span>
            <div>
                <button onclick="concluirTarefa(${indice})">Concluir</button>
                <button onclick="removerTarefa(${indice})">Remover</button>
            </div>
        `;

    lista.appendChild(li);
  });
};

function removerTarefa(indice) {
  if (confirm("Tem certeza que deseja remover esta tarefa?")) {
    tarefas.splice(indice, 1);

    mostrarTarefas();
  }
}

function concluirTarefa(indice) {
  tarefas[indice].concluida = !tarefas[indice].concluida;

  mostrarTarefas();
}

document
  .getElementById("novaTarefa")
  .addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      adicionarTarefa();
    }
  });

mostrarTarefas();
