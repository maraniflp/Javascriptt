document.addEventListener("Carregamento", function () {
  const formulario = document.getElementById("meuFormulario");
  const listaInformacoes = document.getElementById("listaInformacoes");
  const botaoLimpar = document.getElementById("limparLista");

  formulario.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const telefone = document.getElementById("telefone").value.trim();
    const nascimento = document.getElementById("nascimento").value;
    const email = document.getElementById("email").value.trim();

    if (!username || !password || !telefone || !nascimento || !email) {
      console.error("Todos os campos devem ser preenchidos!");
      alert("Por favor, preencha todos os campos!");
      return;
    }

    adicionarInformacao(username, password, telefone, nascimento, email);

    formulario.reset();
  });

  function adicionarInformacao(
    username,
    password,
    telefone,
    nascimento,
    email
  ) {
    const novaInfo = document.createElement("div");
    novaInfo.classList.add("informacao");

    novaInfo.innerHTML = `
            <p><strong>Usuário:</strong> ${username}</p>
            <p><strong>Senha:</strong> ${"*".repeat(password.length)}</p>
            <p><strong>Telefone:</strong> ${telefone}</p>
            <p><strong>Nascimento:</strong> ${dataFormatada}</p>
            <p><strong>E-mail:</strong> ${email}</p>
            <hr>
        `;

    listaInformacoes.appendChild(novaInfo);
  }

  botaoLimpar.addEventListener("click", function () {
    listaInformacoes.innerHTML = "";
    console.log("Lista limpa com sucesso!");
  });
});
