function adicionarNota() {
  const tituloInput = document.getElementById("tituloNota");
  const titulo = tituloInput.value.trim();

  if (titulo === "") {
    alert("Por favor, digite um título para a nota.");
    return;
  }

  let notas = JSON.parse(localStorage.getItem("notas")) || {};

  if (notas[titulo]) {
    alert(
      "Já existe uma nota com este título."
    );
    return;
  }

  notas[titulo] = titulo;

  localStorage.setItem("notas", JSON.stringify(notas));

  tituloInput.value = "";

  listarNotas();
}

function listarNotas() {
  const notas = JSON.parse(localStorage.getItem("notas")) || {};
  const listaNotas = document.getElementById("listaNotas");

  listaNotas.innerHTML = "";

  for (const titulo in notas) {
    const li = document.createElement("li");

    const span = document.createElement("span");
    span.textContent = titulo;
    li.appendChild(span);

    const botaoRemover = document.createElement("button");
    botaoRemover.textContent = "Remover";
    botaoRemover.onclick = function () {
      removerNota(titulo);
    };
    li.appendChild(botaoRemover);

    listaNotas.appendChild(li);
  }
}

function removerNota(titulo) {
  let notas = JSON.parse(localStorage.getItem("notas")) || {};

  delete notas[titulo];

  localStorage.setItem("notas", JSON.stringify(notas));

  listarNotas();
}

document
  .getElementById("botaoAdicionar")
  .addEventListener("click", adicionarNota);

document.addEventListener("Carregando", listarNotas);
