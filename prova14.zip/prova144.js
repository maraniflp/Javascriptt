document.addEventListener('DOMContentLoaded', function() {
    const botaoBuscar = document.getElementById('botaoBuscar');
    const areaResultados = document.getElementById('resultados');
    const urlDaAPI = 'https://jsonplaceholder.typicode.com/users';
    
    botaoBuscar.addEventListener('click', async function() {
        areaResultados.innerHTML = '<p>Buscando dados...</p>';
        
        try {
            const resposta = await fetch(urlDaAPI);
            
            if (!resposta.ok) {
                throw new Error(`Erro: ${resposta.status}`);
            }
            
            const dados = await resposta.json();
            exibirUsuarios(dados);
            
        } catch (erro) {
            areaResultados.innerHTML = `<p>Erro ao buscar os dados: ${erro.message}</p>`;
        }
    });
    
    function exibirUsuarios(listaDeUsuarios) {
        areaResultados.innerHTML = '';
        
        if (listaDeUsuarios.length === 0) {
            areaResultados.innerHTML = '<p>Nenhum usuário encontrado.</p>';
            return;
        }
        
        const lista = document.createElement('ul');
        
        listaDeUsuarios.forEach(usuario => {
            const itemLista = document.createElement('li');
            
            itemLista.innerHTML = `
                <h3>${usuario.name}</h3>
                <p>Usuário: ${usuario.username}</p>
                <p>Email: ${usuario.email}</p>
                <p>Telefone: ${usuario.phone}</p>
                <p>Empresa: ${usuario.company.name}</p>
                <p>Cidade: ${usuario.address.city}</p>
            `;
            
            lista.appendChild(itemLista);
        });
        
        areaResultados.appendChild(lista);
    }
});